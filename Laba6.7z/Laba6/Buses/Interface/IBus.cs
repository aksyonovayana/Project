﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Buses.Interface
{
    internal interface IBus
    {
        int Id {  get; }
        int Capacity {  get; }
    }
}
